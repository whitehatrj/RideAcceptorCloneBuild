# Ride Acceptor Clone (Android source)

This is an independent starter implementation based on the requested workflow. It is **not** a byte-for-byte copy of Ride Acceptor Pro and does not reuse its server, credentials, private APIs, or proprietary code.

## Current functionality
- User-configurable minimum and maximum fare
- User-controlled automatic acceptance toggle
- Sound alert for an offer with an explicit rupee-prefixed fare
- Android Accessibility Service reads visible UI text and taps a visible `Accept`/`Accept ride` control only when the fare is within range
- Settings persist locally

## Important limitations
1. The uploaded APK is obfuscated/protected. Static inspection surfaced Kotlin/AndroidX, Firebase Auth/Realtime Database, WebSocket-related strings, Accessibility APIs, and an app-specific string indicating a WebSocket. This does not reveal its private backend protocol or exact matching logic.
2. The source APK's manifest/resources could not be fully decoded in this environment. The `com.rapido.rider` package identifier is a provisional default; verify the installed Rapido Captain package on the target phone and change it in Profile > Installed app package.
3. Rapido may change its UI, accessibility labels, or policies. The fare parser currently recognizes only visible amounts formatted like `₹123`. It needs validation against genuine, non-sensitive screenshots/test offers before relying on it.
4. Accessibility automation can be restricted by Rapido's terms or platform policies. Use only with explicit user consent and where permitted. This implementation does not bypass login, app integrity checks, anti-fraud controls, or network protections.
5. Auto-accept is disabled by default. Test with auto-accept OFF first.

## Build
Open this folder in Android Studio (Giraffe or newer), install Android SDK Platform 35, then Build > Build Bundle(s) / APK(s) > Build APK(s). Or run:

```bash
gradle assembleDebug
```

The resulting debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Next engineering steps
- Verify the real Captain package name and visible offer screen structure.
- Add explicit parsing for the actual fare layout and avoid confusing fare with incentives/other amounts.
- Add ride de-duplication based on offer identifiers and confirmation-state detection.
- Add a visible service status and an emergency stop.
- Test Android 13–16 notification/accessibility behaviour and Rapido policy compliance.

## Screenshot-informed interface
The app UI now includes a dark dashboard, green accent styling, engine toggle, fare range, driver busy pause, sound alerts, and Dashboard / Filters / History / Profile navigation. The Filters tab includes platform minimum fare, distance range, fare-per-km and mode toggles, based on the supplied screenshots.
