package com.example.rideacceptorclone

import android.accessibilityservice.AccessibilityService
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.util.Locale

class RideAccessibilityService : AccessibilityService() {
    private var lastAcceptedSignature = ""
    private var lastAlertAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val prefs = getSharedPreferences("ride_prefs", MODE_PRIVATE)
        val expectedPackage = prefs.getString("pkg", "com.rapido.rider")
        if (event.packageName?.toString() != expectedPackage) return

        val root = rootInActiveWindow ?: return
        val allText = StringBuilder()
        collectText(root, allText)
        val visible = allText.toString()
        val fare = extractFare(visible) ?: return

        val min = prefs.getString("min", "30")?.toDoubleOrNull() ?: 30.0
        val max = prefs.getString("max", "500")?.toDoubleOrNull() ?: 500.0
        if (fare < min || fare > max) return

        val signature = "${fare}_${visible.hashCode()}"
        val now = System.currentTimeMillis()
        if (prefs.getBoolean("sound", true) && now - lastAlertAt > 2500) {
            try { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 180) } catch (_: Exception) {}
            lastAlertAt = now
        }

        if (!prefs.getBoolean("auto", false) || signature == lastAcceptedSignature) return

        val accept = findAcceptNode(root) ?: return
        val clicked = accept.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        if (clicked) {
            lastAcceptedSignature = signature
            Toast.makeText(this, "Matching ride accepted (if the Captain app confirms it).", Toast.LENGTH_SHORT).show()
        }
    }

    private fun collectText(node: AccessibilityNodeInfo, out: StringBuilder) {
        node.text?.let { if (it.isNotBlank()) out.append(it).append(' ') }
        node.contentDescription?.let { if (it.isNotBlank()) out.append(it).append(' ') }
        for (i in 0 until node.childCount) node.getChild(i)?.let { child ->
            collectText(child, out); child.recycle()
        }
    }

    private fun extractFare(text: String): Double? {
        // Intentionally conservative: only recognize explicit rupee-prefixed amounts.
        val regex = Regex("""₹\s*([0-9]{1,5}(?:,[0-9]{3})*(?:\.[0-9]{1,2})?)""")
        return regex.find(text)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull()
    }

    private fun findAcceptNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val label = listOf(node.text?.toString(), node.contentDescription?.toString())
            .filterNotNull().joinToString(" ").lowercase(Locale.ROOT)
        if (label.trim() in setOf("accept", "accept ride", "book")) {
            if (node.isClickable) return node
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                val result = findAcceptNode(child)
                if (result != null) return result
                child.recycle()
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findAcceptNode(child)
            if (result != null) return result
            child.recycle()
        }
        return null
    }

    override fun onInterrupt() {}
}
