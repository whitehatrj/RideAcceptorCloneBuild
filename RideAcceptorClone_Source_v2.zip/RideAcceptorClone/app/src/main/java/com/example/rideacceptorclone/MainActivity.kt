package com.example.rideacceptorclone

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("ride_prefs", MODE_PRIVATE) }
    private val bg = Color.rgb(8, 13, 21)
    private val panel = Color.rgb(15, 22, 31)
    private val green = Color.rgb(0, 235, 145)
    private val border = Color.rgb(13, 75, 57)
    private lateinit var content: LinearLayout
    private var currentTab = "Dashboard"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showTab("Dashboard")
    }

    private fun showTab(tab: String) {
        currentTab = tab
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 18) }
        scroll.addView(content)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setBackgroundColor(panel); setPadding(4, 10, 4, 10)
        }
        listOf("Dashboard", "Filters", "History", "Profile").forEach { name ->
            val b = TextView(this).apply {
                text = (if (name == tab) "●\\n" else "○\\n") + name
                gravity = Gravity.CENTER; textSize = 13f
                setTextColor(if (name == tab) green else Color.LTGRAY)
                setPadding(5, 4, 5, 4)
                setOnClickListener { showTab(name) }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        outer.addView(nav)
        setContentView(outer)
        when(tab) {
            "Dashboard" -> dashboard()
            "Filters" -> filters()
            "History" -> history()
            else -> profile()
        }
    }

    private fun heading(s: String, size: Float = 25f) {
        content.addView(TextView(this).apply {
            text=s; textSize=size; setTextColor(green); typeface=Typeface.DEFAULT_BOLD
            setPadding(0, 4, 0, 12)
        })
    }
    private fun note(s: String, color: Int = Color.LTGRAY) {
        content.addView(TextView(this).apply { text=s; textSize=14f; setTextColor(color); setPadding(0, 2, 0, 12) })
    }
    private fun card(title: String, subtitle: String? = null): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(12, 38, 28))
        }
        val titleView=TextView(this).apply { text=title; textSize=19f; setTextColor(Color.WHITE); typeface=Typeface.DEFAULT_BOLD }
        box.addView(titleView)
        if (subtitle != null) box.addView(TextView(this).apply { text=subtitle; textSize=14f; setTextColor(Color.LTGRAY); setPadding(0,6,0,0) })
        val wrapper=LinearLayout(this).apply { setPadding(1,1,1,1); setBackgroundColor(border) }
        wrapper.addView(box)
        val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,10,0,12)
        content.addView(wrapper,lp)
        return box
    }
    private fun toggle(parent: LinearLayout, label: String, key: String, default: Boolean, subtitle: String? = null) {
        val row=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,12,0,8) }
        val sw=Switch(this).apply {
            text=label; textSize=17f; setTextColor(Color.WHITE)
            isChecked=prefs.getBoolean(key,default)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key,checked).apply() }
        }
        row.addView(sw)
        if(subtitle!=null) row.addView(TextView(this).apply { text=subtitle; textSize=13f; setTextColor(Color.LTGRAY) })
        parent.addView(row)
    }
    private fun edit(parent: LinearLayout, label: String, key: String, default: String, hint: String = default): EditText {
        parent.addView(TextView(this).apply { text=label; textSize=13f; setTextColor(Color.LTGRAY); setPadding(0,10,0,4) })
        return EditText(this).apply {
            setSingleLine(true); setText(prefs.getString(key,default)); this.hint=hint
            textSize=18f; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setPadding(14,12,14,12); setBackgroundColor(Color.rgb(12,30,28))
            inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            parent.addView(this, LinearLayout.LayoutParams(-1,-2))
        }
    }
    private fun stringEdit(parent: LinearLayout, label: String, key: String, default: String): EditText {
        parent.addView(TextView(this).apply { text=label; textSize=13f; setTextColor(Color.LTGRAY); setPadding(0,10,0,4) })
        return EditText(this).apply {
            setSingleLine(true); setText(prefs.getString(key,default)); textSize=15f
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setPadding(14,12,14,12)
            setBackgroundColor(Color.rgb(12,30,28))
            inputType=android.text.InputType.TYPE_CLASS_TEXT
            parent.addView(this, LinearLayout.LayoutParams(-1,-2))
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    prefs.edit().putString(key,s?.toString()?.trim()).apply()
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
    }
    private fun saveButton(parent: LinearLayout, label: String = "SAVE FILTER SETTINGS") {
        parent.addView(Button(this).apply {
            text=label
            setOnClickListener {
                Toast.makeText(this@MainActivity,"Settings saved",Toast.LENGTH_SHORT).show()
            }
        })
    }
    private fun dashboard() {
        heading("⚡ RIDE ACCEPTOR PRO")
        note("Automated Ride Acceptance Engine")
        content.addView(TextView(this).apply {
            text="⚠️ Keep Rapido app language set to ENGLISH"; gravity=Gravity.CENTER
            textSize=15f; setTextColor(Color.WHITE); setPadding(8,14,8,14); setBackgroundColor(Color.rgb(180,0,0))
        })
        val c=card("🎯 Ride Acceptor Engine", if(prefs.getBoolean("engine",false)) "🟢 Actively scanning for rides…" else "⚪ Engine stopped")
        toggle(c,"ENGINE ON","engine",false)
        card("🔴 Filters ENABLED — rides filtered by your rules")
        val stats=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        listOf("💰\\n₹"+prefs.getString("today","0")+"\\nToday","✅\\n"+prefs.getInt("accepted",0)+"\\nAccepted","❌\\n"+prefs.getInt("skipped",0)+"\\nSkipped").forEach { value ->
            val v=TextView(this).apply { text=value; gravity=Gravity.CENTER; textSize=17f; setTextColor(green); setPadding(8,18,8,18); setBackgroundColor(panel) }
            val lp=LinearLayout.LayoutParams(0,-2,1f); lp.setMargins(3,3,3,3); stats.addView(v,lp)
        }
        content.addView(stats)
        heading("💰 FARE FILTER",21f)
        val fare=card("Configure fare range")
        edit(fare,"Minimum fare (₹)","min","200")
        edit(fare,"Maximum fare (₹)","max","9999")
        toggle(card("⏸️ Driver Busy Pause","Pause engine for 10 minutes after accepting a ride"),"Enable busy pause","busy_pause",false)
        toggle(card("🔊 Ride Acceptance Alerts","Speak accepted ride details at full volume"),"Voice / sound alerts","sound",true)
        content.addView(Button(this).apply { text="OPEN ACCESSIBILITY SETTINGS"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        note("Auto-accept is controlled by your engine setting. Test with the engine OFF first.")
    }
    private fun filters() {
        heading("⚙️ RIDE FILTERS")
        note("🔒 ENGINE " + if(prefs.getBoolean("engine",false)) "RUNNING" else "STOPPED", Color.rgb(255,120,70))
        card("🔒 Turn off the engine to modify filters. Changes apply automatically on next start.")
        note("Configure acceptance rules — changes apply when engine starts")
        val all=card("🎛️ Enable All Filters")
        toggle(all,"Enable all filters","filters_enabled",true,"When OFF, fare and distance filters are ignored")
        heading("💰 PLATFORM FARE",21f)
        val platform=card("Platform-specific minimum fare (overrides global)")
        edit(platform,"Rapido minimum fare (₹)","platform_min","200")
        heading("📏 DISTANCE FILTERS",21f)
        val dist=card("Pickup / trip distance")
        edit(dist,"Minimum distance (km)","min_distance","5")
        edit(dist,"Maximum distance (km)","max_distance","80")
        edit(dist,"Minimum fare per km (₹)","per_km","5")
        heading("🔀 MODE TOGGLES",21f)
        val modes=card("Ride handling rules")
        toggle(modes,"Auto-reject bad rides","reject_bad",true)
        toggle(modes,"Automatic ride acceptance","auto",false,"Only accept visible offers within your configured rules")
        toggle(modes,"Play ride alerts","sound",true)
        saveButton(content)
        content.addView(Button(this).apply { text="TURN ENGINE ON / OFF"; setOnClickListener {
            prefs.edit().putBoolean("engine",!prefs.getBoolean("engine",false)).apply()
            showTab("Filters")
        } })
    }
    private fun history() {
        heading("🕘 RIDE HISTORY")
        note("Accepted and skipped counts are stored locally on this device.")
        card("Accepted rides: ${prefs.getInt("accepted",0)}")
        card("Skipped rides: ${prefs.getInt("skipped",0)}")
        note("Detailed trip history requires a confirmed ride event from the Captain app. No private account data is collected.")
    }
    private fun profile() {
        heading("👤 PROFILE & PERMISSIONS")
        card("Rapido Captain integration","Accessibility service reads visible ride offer details on your device.")
        val pkg=card("Captain app package name")
        stringEdit(pkg,"Installed app package","pkg","com.rapido.rider")
        content.addView(Button(this).apply { text="OPEN ACCESSIBILITY SETTINGS"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        content.addView(Button(this).apply { text="SAVE SETTINGS"; setOnClickListener { Toast.makeText(this@MainActivity,"Settings are saved automatically",Toast.LENGTH_SHORT).show() } })
        note("This is an independent companion app, not an official Rapido product.")
    }
}
